def ispalindrome(str):

    i = int(len(str) / 2)

        if str[i:] = str[:i]:
            


#  Programa inacabado