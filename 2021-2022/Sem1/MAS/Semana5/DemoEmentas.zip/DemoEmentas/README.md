## Getting Started
Sample JAVA project for MAS demonstrating an object-oriented implementation
Can be opened with Visual Studio Code.

Run `DemoClass` to start the program.

## Folder Structure
The workspace contains two folders by default, where:
- `src`: the folder to maintain sources
The compiled output files will be generated in the `bin` folder by default.

