package ementas;

public enum VariedadeCarne {
    VACA,
    PORCO,
    PERU,
    FRANGO,
    OUTRA
}
