import numpy as np
import matplotlib.pyplot as plt

# Gravidade
g = 9.8

# Massa
m = 72

# Tempo inicial e final
ti = 0
tf = 300

# Area, ró, u, Cres e Potencia
A = 0.5
Ro = 1.225
u = 0.01
Cres = 0.9
P = 0.48 * 745.699872

# Posição inicial
xx0 = 0
xy0 = 0

# Velocidade inicial
v0 = 0.5
vx0 = v0

# dt incremento do tempo e n numero de intervalos
dt = 0.001
n = int((tf - ti) / dt)

# Vetor tempo
t = np.linspace(ti, tf, n + 1)

# Vetores
xx = np.empty(n + 1)
vx = np.empty(n + 1)
ax = np.empty(n + 1)

# Introduzir x0 e v0 nos vetores da posição e velocidade
xx[0] = xx0
vx[0] = vx0


# Preencher os vetores x, v, a
for i in range(n):    
    # F total = -Frol - Fres + F0 
    ax[i] = -(u * g) - (Cres * A * Ro * vx[i] * vx[i] / (2 * m)) + P / (m * vx[i])
    xx[i + 1] = xx[i] + vx[i] * dt
    vx[i + 1] = vx[i] + ax[i] * dt


      
# Encontrar os dados do trotinetista quando este chega ao x = 2000
for i in range(n):
    if (xx[i] > 2000):
        print("Xx = 2000:")
        print("t >    |       xx >")
        print(t[i], xx[i])
        print("")
        plt.plot(t[i], xx[i], "o", markersize="10", linewidth=5, color="red")
        break


# Plot
plt.plot(t, xx, label="Posição", linestyle='-', linewidth=3, color="turquoise")
plt.plot(t, t * 0, linestyle='-', linewidth=1, color="black")
plt.xlabel("t (s)")
plt.ylabel("x (m)")
plt.legend()         # Legenda só aparece com isto
plt.grid()
plt.show()