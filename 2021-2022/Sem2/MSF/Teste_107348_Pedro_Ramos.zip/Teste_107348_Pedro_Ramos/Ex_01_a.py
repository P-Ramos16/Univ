import numpy as np
import matplotlib.pyplot as plt

# Gravidade
g = 9.8

# Tempo inicial e final
ti = 0
tf = 1

# Velocidade terminal
vtx = 100 * 1000 / 3600
vty = 100 * 1000 / 3600

# Angulo inicial
alpha = 16

# Posição inicial
xx0 = 0
xy0 = 0

# Velocidade inicial
v0 = 100 * 1000 / 3600

vx0 = v0 * np.cos(np.deg2rad(alpha))
vy0 = v0 * np.sin(np.deg2rad(alpha))


# Calcular D para a resistencia do ar
Dx = g / (vtx * np.abs(vtx))
Dy = g / (vty * np.abs(vty))

# dt incremento do tempo e n numero de intervalos
dt = 0.001
n = int((tf - ti) / dt)

# Vetor tempo
t = np.linspace(ti, tf, n + 1)

# Vetores
xx = np.empty(n + 1)
vx = np.empty(n + 1)
ax = np.empty(n + 1)

xy = np.empty(n + 1)
vy = np.empty(n + 1)
ay = np.empty(n + 1)

# Introduzir x0 e v0 nos vetores da posição e velocidade
xx[0] = xx0
vx[0] = vx0

xy[0] = xy0
vy[0] = vy0


# Preencher os vetores x, v, a
for i in range(n):
    vTotal = np.sqrt(vx[i] ** 2 + vy[i] ** 2)
        
    ax[i] = - Dx * np.abs(vTotal) * vx[i]
    xx[i + 1] = xx[i] + vx[i] * dt
    vx[i + 1] = vx[i] + ax[i] * dt
    
    ay[i] = - Dy * np.abs(vTotal) * vy[i] - g
    xy[i + 1] = xy[i] + vy[i] * dt
    vy[i + 1] = vy[i] + ay[i] * dt


# Encontrar os dados da bola quando esta chega à baliza (x = 20)
for i in range(n):
    if (xx[i] > 20):
        print("Xx = 20:")
        print("t >               |     xx >        |     yy >         |   vy >")
        print(t[i], xx[i], xy[i], vy[i])
        print("")
        plt.plot(xx[i], xy[i], "o", markersize="10", linewidth=5, color="red")
        break


# Plot
plt.scatter(20, 2.4, label="trave", color="black")
plt.plot(xx, xy, label="y(x)",  linestyle='-', linewidth=3, color="turquoise")
plt.xlabel("x (t)")
plt.ylabel("y (t)")
plt.legend()         # Legenda só aparece com isto
plt.grid()
plt.show()


