import numpy as np
import sympy as sym
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D



# Gravidade
g = 9.8

# Tempo inicial e final
ti = 0
tf = 1

# Massa
m = 0.45
r = 0.11
A = np.pi * r ** 2
P_ar = 1.225

# Velocidade terminal (paraquedas fechado)
vtx = 100 * 1000 / 3600
vty = 100 * 1000 / 3600
vtz = 100 * 1000 / 3600

# Angulo inicial
alpha = 16

# Posição inicial
xx0 = 0
xy0 = 0
xz0 = 0

# Aceleração inicial
ax0 = 0
ay0 = 0
az0 = 0

# Rotação inicial
wx = 0
wy = 0
wz = -10

# Velocidade inicial
v0 = 100 * 1000 / 3600

vx0 = v0 * np.cos(np.deg2rad(alpha))
vy0 = v0 * np.sin(np.deg2rad(alpha))
vz0 = 0

# Calcular D para a resistencia do ar
Dx = g / (vtx * np.abs(vtx))
Dy = g / (vty * np.abs(vty))
Dz = g / (vtz * np.abs(vtz))

# dt incremento do tempo e n numero de intervalos
dt = 0.001
n = int((tf - ti) / dt)



# Vetor tempo
t = np.linspace(ti, tf, n + 1)

# Vetores
xx = np.empty(n + 1)
vx = np.empty(n + 1)
ax = np.empty(n + 1)

xy = np.empty(n + 1)
vy = np.empty(n + 1)
ay = np.empty(n + 1)

xz = np.empty(n + 1)
vz = np.empty(n + 1)
az = np.empty(n + 1)

# Introduzir x0 e v0 nos vetores da posição e velocidade
xx[0] = xx0
vx[0] = vx0
ax[0] = ax0

xy[0] = xy0
vy[0] = vy0
ay[0] = ay0

vz[0] = xz0
vz[0] = vz0
az[0] = az0



# Preencher os vetores x, v, a
for i in range(n):
    vTotal = np.sqrt(vx[i] ** 2 + vy[i] ** 2 + vz[i] ** 2)
    
    # Força magnus
    mag = 0.5 * P_ar * r * A
    
    # Aceleração magnus
    amx = mag * wz * vy[i] / m
    ax[i] = - Dx * np.abs(vTotal) * vx[i] + amx
    xx[i + 1] = xx[i] + vx[i] * dt
    vx[i + 1] = vx[i] + ax[i] * dt
    
    ay[i] = - Dy * np.abs(vTotal) * vy[i] - g 
    xy[i + 1] = xy[i] + vy[i] * dt
    vy[i + 1] = vy[i] + ay[i] * dt
    
    amz =  - mag * wz * vx[i] / m
    az[i] = - Dy * np.abs(vTotal) * vz[i] + amz
    xz[i + 1] = xz[i] + vz[i] * dt
    vz[i + 1] = vz[i] + az[i] * dt
    
      
      
fig = plt.figure(figsize = (10, 10), facecolor="dodgerblue")
ax = fig.add_subplot(111, projection ='3d')

# Encontrar os dados da bola quando esta chega à baliza (x = 20)
for i in range(n):
    if (xx[i] > 20):
        print("Xx = 20:")
        print("t >    |       xx >          |     yy >          |     zz >")
        print(t[i], xx[i], xy[i], xz[i])
        print("")
        ax.scatter(xx[i], xz[i], xy[i], label="Posição Final",  linewidth=5, color="red")
        break
   

ax.scatter(xx0, xz0, xy0, label="Posição Inicial",  linewidth=5, color="dodgerblue")
ax.plot(xx, xz, xy, label="Posição",  linestyle='-', linewidth=3, color="turquoise")

ax.set_xlim(0, 20)
ax.set_ylim(-4, 4)
ax.set_zlim(0, 3)
ax.set_xlabel("x (m)")
ax.set_ylabel("z (m)")
ax.set_zlabel("y (m)")
plt.legend()         # Legenda só aparece com isto
plt.grid()
plt.show()
    
    