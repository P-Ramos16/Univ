package a107348;

import java.util.*;

public abstract class Activity {
    protected int numParti;

    public abstract double getPreco();
    
    public int getNumParti() {
        return numParti;
    }
    
}
