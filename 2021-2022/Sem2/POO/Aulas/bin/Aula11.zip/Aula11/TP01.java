package Aula11;

import java.util.Scanner;
import java.io.FileReader;

import java.util.*;
import java.io.*;

public class TP01 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<String> wordsArray = new ArrayList<String>();
        ArrayList<String> wordsSArray = new ArrayList<String>();
        ArrayList<String> wordsCleanArray = new ArrayList<String>();



        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┃                             ┃");
        System.out.println("┃            TP_01            ┃");
        System.out.println("┃                             ┃");
        System.out.println("┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫");
        System.out.println("┃                             ┃");
        System.out.println("┃  Insira o nome do ficheiro  ┃");
        System.out.println("┃                             ┃");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        System.out.print("       >");
        String name = sc.nextLine();
        System.out.println("");




    }
}
