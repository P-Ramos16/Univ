package Aula08.Ex01;

public interface VeiculoEletrico {
    int autonomia();
    void carregar(int percentagem);
}
