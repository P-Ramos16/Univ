package Aula08.Ex02;

public class DiaSemana {    
	public static String[] values() {
		String[] arr = {"Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado", "Domingo"};
		return arr;
	}
}
