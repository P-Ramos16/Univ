package Aula12;

import java.util.*;
import java.io.*;
import java.nio.*;

public class Ex01 {
    public static void main(String[] args) {

        //  Janela Inicial
        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┃                             ┃");
        System.out.println("┃            TP_12            ┃");
        System.out.println("┃                             ┃");
        System.out.println("┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫");
        System.out.println("┃                             ┃");
        System.out.println("┃    Resultado do programa:   ┃");
        System.out.println("┃                             ┃");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        System.out.println("");

        TreeSet<String> wordSet = new TreeSet<String>();
        int numTotal = 0;

        try {
            Scanner inFile = new Scanner(new File("Aula12/lorem.txt"));
            while (inFile.hasNextLine()) {
                String[] words = inFile.nextLine().split("[ \n]");
                
                for (String word : words) {
                    wordSet.add(word);
                    numTotal++;
                }                
            }

            System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
            System.out.println("┃                             ┃");
            System.out.println("┃           Valores           ┃");
            System.out.println("┃                             ┃");
            System.out.println("┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫");
            System.out.println("┃  Número Total de Palavras > ┃");
            System.out.printf("┃             %-16s┃\n", numTotal);
            System.out.println("┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫");  
            System.out.println("┃  Número de Palavras Dife. > ┃");
            System.out.printf("┃             %-16s┃\n", wordSet.size());
            System.out.println("┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫");
            System.out.println("┃          Exiting...         ┃");
            System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
            
        }

        catch(FileNotFoundException e) {
            System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
            System.out.println("┃                             ┃");
            System.out.println("┃           ERRO!!            ┃");
            System.out.println("┃    ficheiro não existente   ┃");
            System.out.println("┃                             ┃");
            System.out.println("┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫");
            System.out.println("┃          Exiting...         ┃");
            System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
            System.exit(0);
        }
    
    
    }
}
