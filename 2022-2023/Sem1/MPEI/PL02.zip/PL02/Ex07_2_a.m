lambda = 15;

k = 0;
PkA = ((lambda)^k / factorial(k)) * exp(-lambda)

