function J = minHashUser(Set,Nu, userID)
    %% Calcula a distância de Jaccard entre todos os pares pela definição.
    J = zeros(Nu); % array para guardar distâncias
    numHashF = 100;
    Assinaturas = zeros(Nu, numHashF);

    bar = waitbar(0, "Calculating");
    tic
    for n1 = 1:1:Nu
        waitbar(n1/Nu,bar);
        conjunto = Set{n1,:};
        keys = string(conjunto(:,1)');
        for fh = 1:1:numHashF
            h = zeros(length(conjunto), 1)';
            for i = 1:1:length(conjunto)
                keys(i) = keys(i) + (fh);
                h(i) = rem(DJB31MA(keys(i), 255), Nu*numHashF) + 1;
            end
            Assinaturas(n1,fh) = min(h);
        end
    end
    toc
    close(bar);
    % Para cada user n1 comparar com o user Inicial
    for n1 = 1:Nu
        J(n1) = sum(Assinaturas(n1,:) ~= Assinaturas(userID,:))/numHashF;
    end
end

