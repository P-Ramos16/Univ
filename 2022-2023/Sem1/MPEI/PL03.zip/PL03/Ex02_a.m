matEstados = [1/3  1/4   0
              1/3 11/20 1/2
              1/3  1/5  1/2];

sum(matEstados)
matEstados >= 0 & matEstados <= 1
% Tudo uns, logo é estocástica