nAlunos = 90;

vetEstado1 = [60 15 15]' / nAlunos