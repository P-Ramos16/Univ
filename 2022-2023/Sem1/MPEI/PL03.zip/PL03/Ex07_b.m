%  C e D são spider traps pois só tem saidas para uma
% das duas, sendo impossível sair do loop gerado entre elas
%
%  F é um dead end pois não tem 
% qualquer saida sem ser para si próprio