

k = 1;
pfalsosPos = 0.03;
m = 300

a = 1 - pfalsosPos % Ignorar roots porque o k = 1

tamanho = 1 / (1 - nthroot(a, m))