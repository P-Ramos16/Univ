function bitArray = initialize(n, k)
%INITIALIZE Summary of this function goes here
%   Detailed explanation goes here
    bitArray = zeros(1, n, "uint8");
end

