clear all;
load("Mensagem.mat");
simbolos = alfabeto1(Mensagem);

simbolos