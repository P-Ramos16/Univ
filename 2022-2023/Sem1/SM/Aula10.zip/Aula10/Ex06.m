clear all;
load("Mensagem.mat");
H = entropia('AABCABABAAABBCABCAAC');
H

H = entropia(Mensagem);
H